## Lable notations

P: praise
B: bug
E: aspect evaluation 
N: others
R: feature request

## How to convert the data into an excel format?
Rename it to ".prn" and open with excel. 